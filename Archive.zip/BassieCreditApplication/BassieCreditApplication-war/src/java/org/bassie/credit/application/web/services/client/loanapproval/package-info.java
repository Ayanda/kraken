@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.web.loanapproval.org/")
package org.bassie.credit.application.web.services.client.loanapproval;
