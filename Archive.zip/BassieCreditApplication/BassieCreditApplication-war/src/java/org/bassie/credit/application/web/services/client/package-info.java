@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.web.customerservice.org/")
package org.bassie.credit.application.web.services.client;
