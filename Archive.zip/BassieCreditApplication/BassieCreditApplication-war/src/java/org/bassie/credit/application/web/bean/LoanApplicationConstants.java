/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.bassie.credit.application.web.bean;

/**
 *
 * @author Ayanda
 */
public class LoanApplicationConstants {
    
    public static final String START_PAGE = "welcomePrimefaces.xhtml";
    public static final String APPLY_PAGE = "apply.xhtml";
    public static final String APPROVE_PAGE = "approve.xhtml";
    public static final String HOME_PAGE = "index.xhtml";
}
